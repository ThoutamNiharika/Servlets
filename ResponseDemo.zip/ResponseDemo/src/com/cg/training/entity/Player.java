package com.cg.training.entity;

public class Player {
	private int playerId;
	private String playerName;
	private int numberOfMatches;
	private int totalRunsScore;
	private int numberOfWickets;
	private boolean captain;
	
	
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getNumberOfMatches() {
		return numberOfMatches;
	}
	public void setNumberOfMatches(int numberOfMatches) {
		this.numberOfMatches = numberOfMatches;
	}
	public int getTotalRunsScore() {
		return totalRunsScore;
	}
	public void setTotalRunsScore(int totalRunsScore) {
		this.totalRunsScore = totalRunsScore;
	}
	public int getNumberOfWickets() {
		return numberOfWickets;
	}
	public void setNumberOfWickets(int numberOfWickets) {
		this.numberOfWickets = numberOfWickets;
	}
	public boolean isCaptain() {
		return captain;
	}
	public void setCaptain(boolean captain) {
		this.captain = captain;
	}
	public Player(int playerId, String playerName, int numberOfMatches,
			int totalRunsScore, int numberOfWickets, boolean captain) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.numberOfMatches = numberOfMatches;
		this.totalRunsScore = totalRunsScore;
		this.numberOfWickets = numberOfWickets;
		this.captain = captain;
	}
	public Player() {
		super();
	}
	
	
	
	
	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName
				+ ", numberOfMatches=" + numberOfMatches + ", totalRunsScore="
				+ totalRunsScore + ", numberOfWickets=" + numberOfWickets
				+ ", captain=" + captain + "]";
	}
	public String getBattingRating()
	{
		double average=this.totalRunsScore/this.numberOfMatches;
		if(average>90)
		{
			return "best";
		}
		else if(average>=50)
			return "good";
		else if(average>=25)
			return "average";
		else
			return "poor";
	}
	
	public String getBowlingRating()
	{
		double average=this.numberOfWickets/this.numberOfMatches;
		if(average>90)
		{
			return "best";
		}
		else if(average>=50)
			return "good";
		else if(average>=25)
			return "average";
		else
			return "poor";
	}
}
