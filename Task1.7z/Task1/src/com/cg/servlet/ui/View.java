package com.cg.servlet.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.servlet.entity.FormDetails;

/**
 * Servlet implementation class View
 */
@WebServlet("/View")
public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;
      

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html"); 
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		
		FormDetails details=(FormDetails) session.getAttribute("firstName");
		
		out.println("FirstName: " +details.getFname());
		out.println("LastName: " +details.getLname());
		out.println("DateOfBirth: " +details.getDob());
		out.println("Gender: " +details.getGender());
		out.println("Language: " +details.getLang());
		out.println("Address: " +details.getAddress());
		out.println("City: " +details.getCity());
		out.println("PhoneNumber: " +details.getPhno());
		out.println("AccountNumber: " +details.getAccno());
		out.println("PAN: " +details.getPAN());
		out.println("CreditCardNumber: " +details.getCredit());
		out.println("NumberOfYears: " +details.getNoofyr());
		out.println("RateOfInterest: " +details.getRoi());
		out.println("Amount: " +details.getAmt());
		out.println("Email: " +details.getEmail());
		
		
		
	}

}
