package com.cg.servlet.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.servlet.entity.FormDetails;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");  
		 
		 
		 PrintWriter out=response.getWriter();
		 
		 
		 String firstName=request.getParameter("fname");
		 String lname=request.getParameter("lname");
		 String dob=request.getParameter("dob");
		 String gender=request.getParameter("gender");
		 String lang=request.getParameter("lang");
		 String address=request.getParameter("address");
		 String city=request.getParameter("city");
		 String phno=request.getParameter("phno");
		 String accno=request.getParameter("accno");
		 String pan=request.getParameter("PAN");
		 String credit=request.getParameter("credit");
		 String noofyr=request.getParameter("noofyr");
		 String roi=request.getParameter("roi");
		 String amt=request.getParameter("amt");
		 String loanType=request.getParameter("loanType");
		 String email=request.getParameter("email");
		 
		 FormDetails entity=new FormDetails();
		 entity.setFname(firstName);
		 entity.setLname(lname);
		 entity.setDob(dob);
		 entity.setGender(gender);
		 entity.setLang(lang);
		 entity.setAddress(address);
		 entity.setCity(city);
		 entity.setPhno(phno);
		 entity.setAccno(accno);
		 entity.setPAN(pan);
		 entity.setCredit(credit);
		 entity.setNoofyr(noofyr);
		 entity.setRoi(roi);
		 entity.setAmt(amt);
		 entity.setLoanType(loanType);
		 entity.setEmail(email);
		 
		 
		 HttpSession session=request.getSession();
		
		 session.setAttribute("firstName", entity);
		 RequestDispatcher rd=request.getRequestDispatcher("View");  
	        rd.forward(request, response); 
		 
		
		
	}

}
