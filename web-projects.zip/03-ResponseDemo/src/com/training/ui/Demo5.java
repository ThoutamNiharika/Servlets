package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Set<Player> players = new HashSet<Player>();
		PrintWriter out = response.getWriter();
		Player player1 = new Player(101, "Ganguly", 320, 11290, 300, true);
		Player player2 = new Player(102, "Sachin", 452, 18460, 280, false);
		Player player3 = new Player(103, "Dravid", 344, 12500, 100, false);
		Player player4 = new Player(104, "Sehwag", 280, 7749, 180, false);
		Player player5 = new Player(105, "Lakshman", 220, 6800, 120, false);
		Player player6 = new Player(106, "Yuvraj", 302, 9430, 250, false);
		Player player7 = new Player(107, "Dhoni", 285, 10970, 160, false);
		Player player8 = new Player(108, "Harbhajan", 337, 4600, 380, false);
		Player player9 = new Player(109, "Kumble", 414, 2800, 420, false);
		Player player10 = new Player(110, "Irfan", 180, 8600, 225, false);
		Player player11 = new Player(111, "Zaheer", 278, 2600, 350, false);
		players.add(player1);
		players.add(player2);
		players.add(player3);
		players.add(player4);
		players.add(player5);
		players.add(player6);
		players.add(player7);
		players.add(player8);
		players.add(player9);
		players.add(player10);
		players.add(player11);

		response.setContentType("text/html");
		out.println("<head>");
		out.println("<title>Indian Cricket Team</title>");
		out.println("<link href='style.css' rel='stylesheet' />");
		out.println("</head>");
		
	
		out.println("<th>" + "<tr>" + "PlayerId" + "  " + "PlayerName" + "  "
				+ "Matches" + "  " + "Runs" + "  " + "Wickets" + "  "
				+ "BattingRating" + "  " + "BowlingRating" + "</tr>" + "</th>");

		out.println("<table>");
		for (Player player : players) {
			
			out.println("<tr>");
			out.println("<td>" + player.getPlayerId() + "</td>");
			out.println("<td>" + player.getPlayerName() + "</td>");
			out.println("<td>" + player.getTotalRunsScored() + "</td>");
			out.println("<td>" + player.getNumberOfMatches() + "</td>");
			out.println("<td>" + player.getNumberOfWickets() + "</td>");
			out.println("<td>" + player.getBattingRating() + "</td>");
			out.println("<td>" + player.getBowlingRating() + "</td>");
			out.println("</tr>");
		}

		out.println("</table>");

	}

}
